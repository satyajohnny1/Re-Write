package springdata;

public class Student {

}
