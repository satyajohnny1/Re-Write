import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable {
            // Exception in thread "main" java.io.NotSerializableException: io.Student
            private static int sno;
            private String name;
            private String addr;
			public int getSno() {
				return sno;
			}
			public void setSno(int sno) {
				this.sno = sno;
			}
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public String getAddr() {
				return addr;
			}
			public void setAddr(String addr) {
				this.addr = addr;
			}
            
            
        }
        public class Demo {
        	public static void main(String[] args) throws  Exception {
        		Student student = new Student();
        	    student.setSno(101);
        	    student.setName("Satya Kaveti");
        	    student.setAddr("VIJAYAWADA");
        	    
        	    Student s2 = new Student();
        	    s2.setName("Raj Kaveti");
        	    s2.setAddr("VIJAYAWADA");
        	    
        	    FileOutputStream fos = new FileOutputStream("student.txt");
        	    ObjectOutputStream oos = new ObjectOutputStream(fos);
        	    oos.writeObject(student); 
        	    oos.writeObject(s2); 
        	    
        	    FileInputStream fis = new FileInputStream("student.txt");
                ObjectInputStream ois = new ObjectInputStream(fis);
                Student st = (Student)ois.readObject();
                System.out.println(st.getSno());
                System.out.println(st.getName());
                System.out.println(st.getAddr()); 
        	}
        	}

