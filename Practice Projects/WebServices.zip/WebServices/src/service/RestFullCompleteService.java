package service;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;import com.sun.xml.internal.ws.transport.http.HttpAdapter;

@Path("/student")
public class RestFullCompleteService {
	
	
	@GET
	@Produces("text/html")
	public Response student() {
		System.out.println("======================= 2x ============");
		String output = "<h1> Hello Student</h1>";
		return Response.status(200).entity(output).build();

	}
	//rest/students/101/Satya/Vijayawada
	
	
	@GET
    @Path("/pathparam/{rollno}/{name}/{address}")
    @Produces("text/html")
    public Response getResultByPassingValue(
            @PathParam("rollno") String rollno,
                    @PathParam("name") String name,
                    @PathParam("address") String address) {     
        String output = "<h1>PathParamService Example</h1>";
        output = output+"<br>Roll No : "+rollno;
        output = output+"<br>Name : "+name;
        output = output+"<br>Address : "+address;      
        return Response.status(200).entity(output).build(); 
    }
	

	
	@GET
	@Path("/qryparam")
	@Produces("test/html")	
    public Response QryParam(
    		 @DefaultValue("1000")  @QueryParam("rollno") String rollno,
    		 @DefaultValue("xxxx")  @QueryParam("name") String name,
    		 @DefaultValue("xxxx")  @QueryParam("address") String address) {        
        String output = "<h1>QueryParamService Example</h1>";
        output = output+"<br>Roll No : "+rollno;
        output = output+"<br>Name : "+name;
        output = output+"<br>Address : "+address;
         
        return Response.status(200).entity(output).build();
 
    }
	
	
	//rest/student/formparam
	@POST
	@Path("/formparam")	
	@Produces("test/html")
	public Response FormParam(
            @FormParam("user") String name,
            @FormParam("pwd") String pwd) {
        
        String output = "<h1>@FormParam Example - REGISTRATION COMPLETED!!!</h1>";
      
        output = output+"<br>Name : "+name;
        output = output+"<br>pwd : "+pwd;      
        return Response.status(200).entity(output).build();
    }
	
	
	@GET
    @Path("/headerparam")
    public Response getHeader(
            @HeaderParam("user-agent") String userAgent,
            @HeaderParam("Accept") String accept,
            @HeaderParam("Accept-Encoding") String encoding,
            @HeaderParam("Accept-Language") String lang) {
        
        String output = "<h1>@Headerparam Example</h1>";
        output = output+"<br>user-agent : "+userAgent;
        output = output+"<br>Accept : "+accept;
        output = output+"<br>Accept-Encoding : "+encoding;
        output = output+"<br>Accept-Language: "+lang;
 
        return Response.status(200)
            .entity(output)
            .build();
 
    }
	
	@GET
    @Path("/json")
    @Produces(MediaType.APPLICATION_JSON)
    public UserBo getboInJSON() {
 
        UserBo bo = new UserBo();
        bo.setUsername("satyakaveti@gmail.com");
        bo.setPassword("XCersxg34CXeWER341DS@#we");
        return bo;
    }
	
}


class UserBo{
	
	 String username;
	    String password;
	 
	    public String getUsername() {
	        return username;
	    }
	 
	    public void setUsername(String username) {
	        this.username = username;
	    }
	 
	    public String getPassword() {
	        return password;
	    }
	 
	    public void setPassword(String password) {
	        this.password = password;
	    }
	 
	    @Override
	    public String toString() {
	        return "USER [username=" + username + ", password=" + password + "]";
	    }
}